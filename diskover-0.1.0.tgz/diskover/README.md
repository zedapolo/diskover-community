# Chart Helm Diskover Community (OpenShift)

Prérequis : OpenShift 4.x, opérateur ECK installé et surveillant le namespace cible, accès sortant vers github.com, pypi.org et cdn-ubi.redhat.com pour les builds.

    oc new-project diskover
    helm install diskover ./diskover -f mes-valeurs.yaml
    oc get builds -w
    oc get route diskover-web

Identifiants initiaux diskover / darkdata : à changer immédiatement (⚙ Settings).
