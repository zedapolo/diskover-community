{{- define "diskover.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 50 | trimSuffix "-" -}}
{{- else if .Values.nameOverride -}}
{{- printf "%s-%s" .Release.Name .Values.nameOverride | trunc 50 | trimSuffix "-" -}}
{{- else -}}
{{- .Release.Name | trunc 50 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "diskover.labels" -}}
app.kubernetes.io/name: diskover
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version }}
{{- end -}}

{{- define "diskover.esHost" -}}
{{- if .Values.elasticsearch.create -}}
{{- printf "%s-es-http" .Values.elasticsearch.name -}}
{{- else -}}
{{- required "elasticsearch.host est obligatoire quand elasticsearch.create=false" .Values.elasticsearch.host -}}
{{- end -}}
{{- end -}}

{{- define "diskover.esSecretName" -}}
{{- if .Values.elasticsearch.create -}}
{{- printf "%s-es-elastic-user" .Values.elasticsearch.name -}}
{{- else -}}
{{- required "elasticsearch.userSecret.name est obligatoire quand elasticsearch.create=false" .Values.elasticsearch.userSecret.name -}}
{{- end -}}
{{- end -}}

{{- define "diskover.esSecretKey" -}}
{{- if .Values.elasticsearch.create -}}elastic{{- else -}}{{ .Values.elasticsearch.userSecret.key }}{{- end -}}
{{- end -}}

{{/* Variables d'environnement lues nativement par diskover (python) et diskover-web (php) */}}
{{- define "diskover.esEnv" -}}
- name: ES_HOST
  value: {{ include "diskover.esHost" . | quote }}
- name: ES_PORT
  value: {{ .Values.elasticsearch.port | toString | quote }}
- name: ES_USER
  value: {{ .Values.elasticsearch.user | quote }}
- name: ES_PASS
  valueFrom:
    secretKeyRef:
      name: {{ include "diskover.esSecretName" . }}
      key: {{ include "diskover.esSecretKey" . }}
- name: ES_HTTPS
  value: {{ ternary "true" "false" .Values.elasticsearch.tls | quote }}
- name: ES_SSLVERIFICATION
  value: {{ ternary "true" "false" .Values.elasticsearch.sslVerification | quote }}
{{- end -}}
